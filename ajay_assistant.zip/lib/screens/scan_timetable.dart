
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:google_ml_kit/google_ml_kit.dart';
import '../services/notification_service.dart';

class ScanTimetableScreen extends StatefulWidget {
  @override
  _ScanTimetableScreenState createState() => _ScanTimetableScreenState();
}

class _ScanTimetableScreenState extends State<ScanTimetableScreen> {
  File? image;
  String extractedText = "";

  Future<void> pickImage() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery);
    if (picked != null) {
      setState(() => image = File(picked.path));
      scanText();
    }
  }

  Future<void> scanText() async {
    if (image == null) return;
    final inputImage = InputImage.fromFile(image!);
    final textRecognizer = GoogleMlKit.vision.textRecognizer();
    final RecognizedText recognized = await textRecognizer.processImage(inputImage);
    setState(() => extractedText = recognized.text);

    if (extractedText.contains("Math")) {
      TimeOfDay time = TimeOfDay(hour: 10, minute: 0);
      NotificationService().scheduleNotification(
        title: "Hi Ajay!",
        body: "Math class is starting soon!",
        time: time,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Scan Timetable")),
      body: Column(
        children: [
          ElevatedButton(onPressed: pickImage, child: Text("Upload Timetable")),
          if (image != null) Image.file(image!, height: 200),
          Padding(
            padding: const EdgeInsets.all(10),
            child: Text(extractedText, style: TextStyle(fontSize: 16)),
          )
        ],
      ),
    );
  }
}
