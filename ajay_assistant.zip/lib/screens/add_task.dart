
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import '../services/notification_service.dart';

class AddTaskScreen extends StatefulWidget {
  @override
  _AddTaskScreenState createState() => _AddTaskScreenState();
}

class _AddTaskScreenState extends State<AddTaskScreen> {
  TextEditingController taskController = TextEditingController();
  TimeOfDay? selectedTime;
  final FlutterTts tts = FlutterTts();

  Future<void> pickTime() async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );
    if (picked != null) setState(() => selectedTime = picked);
  }

  void saveTask() {
    if (taskController.text.isNotEmpty && selectedTime != null) {
      NotificationService().scheduleNotification(
        title: "Hi Ajay!",
        body: "It's time to ${taskController.text}",
        time: selectedTime!,
      );
      tts.speak("Hi Ajay, it's time to ${taskController.text}");
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Add Task")),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            TextField(
              controller: taskController,
              decoration: InputDecoration(labelText: "Task Name", border: OutlineInputBorder()),
            ),
            SizedBox(height: 20),
            Row(
              children: [
                ElevatedButton(onPressed: pickTime, child: Text(selectedTime == null ? "Pick Time" : selectedTime!.format(context))),
                SizedBox(width: 20),
                ElevatedButton(onPressed: saveTask, child: Text("Save Task")),
              ],
            )
          ],
        ),
      ),
    );
  }
}
