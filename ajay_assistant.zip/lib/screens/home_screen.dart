
import 'package:flutter/material.dart';
import 'add_task.dart';
import 'scan_timetable.dart';
import 'daily_summary.dart';
import 'habit_tracker.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Hi Ajay!")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AddTaskScreen())),
              child: Text("Add Task"),
            ),
            ElevatedButton(
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ScanTimetableScreen())),
              child: Text("Scan Timetable"),
            ),
            ElevatedButton(
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => DailySummaryScreen(completedTasks: 3, totalTasks: 5))),
              child: Text("Daily Summary"),
            ),
            ElevatedButton(
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => HabitTrackerScreen())),
              child: Text("Habit Tracker"),
            ),
          ],
        ),
      ),
    );
  }
}
